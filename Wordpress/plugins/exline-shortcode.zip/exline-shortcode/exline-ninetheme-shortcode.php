<?php
/*
	Plugin Name: Exline Shortcodes
	Plugin URI: http://themeforest.net/user/Ninetheme
	Description: Shortcodes for Ninetheme WordPress Themes - Exline Version
	Version: 1.3.9
	Author: Ninetheme
	Author URI: http://themeforest.net/user/Ninetheme
*/

add_action('plugins_loaded', 'exline_vc_loaded');
function exline_vc_loaded() {

	if ( class_exists('Vc_Manager') ) {

		// image resizer
		require_once plugin_dir_path(__FILE__) . 'aq_resizer.php';

		// shortcode functions
		require_once plugin_dir_path(__FILE__) . 'fronted.php';

	} else {

		require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		deactivate_plugins(plugin_basename(__FILE__));

	}
}
