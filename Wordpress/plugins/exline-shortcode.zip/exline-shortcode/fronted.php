<?php

/*-----------------------------------------------------------------------------------*/
/*	header 1
/*-----------------------------------------------------------------------------------*/

function theme_vc_hero_one( $atts, $content = null ) {
    extract( shortcode_atts(array(
		"image_url"         => '',
		"heading"           => '',
		"description"       => '',
		"scroll_down_link"  => '',
		"tcolor"            => '',
		"tsize"             => '',
		"tlineh"            => '',
    "dcolor"            => '',
		"dsize"             => '',
		"dlineh"            => '',
	), $atts) );

	$image = wp_get_attachment_url( $image_url, 'full' );

	$output = '';
		$output .= '<section id="hero" class="full-screen">';
			$output .= '<div data-background="'. esc_url($image) . '" data-top="transform: translate3d(0px, 0px, 0px)" data-top-bottom="transform: translate3d(0px, -200px, 0px)" data-anchor-target="#hero" class="parallax parallax-hero full-screen bg-dark-50"></div>';
				$output .= '<div class="hero-content">';
					$output .= '<div class="hero-content-inner">';
					if ($heading != ''){
            $t_color       = ( $tcolor !='' ) ? ' color:'.esc_attr( $tcolor ).';' : '';
            $t_size        = ( $tsize  !='' ) ? ' font-size:'.esc_attr( $tsize ).';' : '';
            $t_lineh       = ( $tlineh !='' ) ? ' line-height:'.esc_attr( $tlineh ).';' : '';
            $titlestyle    = ( $t_color   !='' || $t_size !='' || $t_lineh !='' ) ? ' style="'.$t_color.$t_size.$t_lineh.'"' : '';
            $output .= '<div data-wow-delay="0.5s" data-wow-duration="3s" class="hs-line-2 wow fadeInDown" '.$titlestyle.'>'. $heading . '</div>';
           }
					if ($description != ''){
            $d_color       = ( $dcolor !='' ) ? ' color:'.esc_attr( $dcolor ).';' : '';
            $d_size        = ( $dsize  !='' ) ? ' font-size:'.esc_attr( $dsize ).';' : '';
            $d_lineh       = ( $dlineh !='' ) ? ' line-height:'.esc_attr( $dlineh ).';' : '';
            $descstyle    = ( $d_color   !='' || $d_size !='' || $d_lineh !='' ) ? ' style="'.$d_color.$d_size.$d_lineh.'"' : '';
            $output .= '<h1 data-wow-delay="0.5s" data-wow-duration="3s" class="hs-line-1 wow fadeInUp" '.$descstyle.'>'. $description . '</h1>';
          }
					$output .= ''.do_shortcode( $content ).'';
				$output .= '</div>';
			$output .= '</div>';
			if ($scroll_down_link != ''){ $output .= '<a href="'. $scroll_down_link . '" data-start="display: block" data-100-start="display: none" class="btn-scroll-down scroll"></a>'; }
		$output .= ' </section>';

	return $output;
} add_shortcode('vc_hero_one', 'theme_vc_hero_one');

/*-----------------------------------------------------------------------------------*/
/*	header 2
/*-----------------------------------------------------------------------------------*/

function theme_vc_hero_two( $atts, $content = null ) {
    extract( shortcode_atts(array(
		"image_url"       		  => '',
		"heading"       		  => '',
		"slide_items"      	      => '',
		"item_img"      	      => '',
		"description"      	      => '',
		"scroll_down_link"        => '',
    "tcolor"            => '',
		"tsize"             => '',
		"tlineh"            => '',
    "dcolor"            => '',
		"dsize"             => '',
		"dlineh"            => '',
	), $atts) );

	$image 			= 	wp_get_attachment_url( $image_url, 'full' );
	$slide_items 	= 	(array) vc_param_group_parse_atts($slide_items);

	$output = '';
	$output .= '<section id="hero" class="full-screen slideshows">';

		$output .= '<div data-top="transform: translate3d(0px, 0px, 0px)" data-top-bottom="transform: translate3d(0px, -200px, 0px)" data-anchor-target="#hero" class="parallax-hero full-screen bg-slideshow-wrapper">';
			$slide_count = 0;
			foreach ( $slide_items as $item ) {
				$slide_count++;
				$img_url 	= wp_get_attachment_url( $item['item_img'],'full' );
				$bg_img_url = ($img_url != '')  ? 'data-background="'. esc_url($img_url) . '"' : '';
				$output .= '<div '. $bg_img_url . '" class="slideshow slide-'. esc_attr($slide_count) . ' bg-dark-10 bg-img"></div>';
			}
		$output .= '</div>';

		$output .= '<div class="hero-content">';
			$output .= '<div class="hero-content-inner">';
				if ($heading != ''){
          $t_color       = ( $tcolor !='' ) ? ' color:'.esc_attr( $tcolor ).';' : '';
          $t_size        = ( $tsize  !='' ) ? ' font-size:'.esc_attr( $tsize ).';' : '';
          $t_lineh       = ( $tlineh !='' ) ? ' line-height:'.esc_attr( $tlineh ).';' : '';
          $titlestyle    = ( $t_color   !='' || $t_size !='' || $t_lineh !='' ) ? ' style="'.$t_color.$t_size.$t_lineh.'"' : '';
           $output .= '<div data-wow-delay="0.5s" data-wow-duration="3s" class="hs-line-2 wow fadeInDown" '.$titlestyle.'>'. $heading . '</div>';
         }
				if ($description != ''){
          $d_color       = ( $dcolor !='' ) ? ' color:'.esc_attr( $dcolor ).';' : '';
          $d_size        = ( $dsize  !='' ) ? ' font-size:'.esc_attr( $dsize ).';' : '';
          $d_lineh       = ( $dlineh !='' ) ? ' line-height:'.esc_attr( $dlineh ).';' : '';
          $descstyle    = ( $d_color   !='' || $d_size !='' || $d_lineh !='' ) ? ' style="'.$d_color.$d_size.$d_lineh.'"' : '';
          $output .= '<h1 data-wow-delay="0.5s" data-wow-duration="3s" class="hs-line-1 wow fadeInUp" '.$descstyle.'>'. $description . '</h1>';
        }
				$output .= ''.do_shortcode( $content ).'';
			$output .= '</div>';
		$output .= '</div>';
		if ($scroll_down_link != ''){ $output .= '<a href="'. $scroll_down_link . '" data-start="display: block" data-100-start="display: none" class="btn-scroll-down scroll"></a>'; }
	$output .= ' </section>';
	return $output;
} add_shortcode('vc_hero_two', 'theme_vc_hero_two');


/*-----------------------------------------------------------------------------------*/
/*	header 3
/*-----------------------------------------------------------------------------------*/

function theme_vc_hero_three( $atts, $content = null ) {
    extract( shortcode_atts(array(
		"image_url"       		  => '',
		"heading"       		  => '',
		"description"      	      => '',
		"scroll_down_link"        => '',
    "tcolor"            => '',
    "tsize"             => '',
    "tlineh"            => '',
    "dcolor"            => '',
    "dsize"             => '',
    "dlineh"            => '',
	), $atts) );

	wp_enqueue_script( 'particleground');
	$image 	= wp_get_attachment_url( $image_url, 'full' );

	$output = '';
		$output .= '<section id="hero" class="full-screen">';
			$output .= '<div id="particle-ground" data-background="'. esc_url($image) . '" data-top="transform: translate3d(0px, 0px, 0px)" data-top-bottom="transform: translate3d(0px, -200px, 0px)" data-anchor-target="#hero" class="parallax parallax-hero full-screen bg-dark-50"></div>';
				$output .= '<div class="hero-content">';
					$output .= '<div class="hero-content-inner">';
					if ($heading != ''){
            $t_color       = ( $tcolor !='' ) ? ' color:'.esc_attr( $tcolor ).';' : '';
            $t_size        = ( $tsize  !='' ) ? ' font-size:'.esc_attr( $tsize ).';' : '';
            $t_lineh       = ( $tlineh !='' ) ? ' line-height:'.esc_attr( $tlineh ).';' : '';
            $titlestyle    = ( $t_color   !='' || $t_size !='' || $t_lineh !='' ) ? ' style="'.$t_color.$t_size.$t_lineh.'"' : '';
            $output .= '<div data-wow-delay="0.5s" data-wow-duration="3s" class="hs-line-2 wow fadeInDown" '.$titlestyle.'>'. $heading . '</div>';
           }
					if ($description != ''){
            $d_color       = ( $dcolor !='' ) ? ' color:'.esc_attr( $dcolor ).';' : '';
            $d_size        = ( $dsize  !='' ) ? ' font-size:'.esc_attr( $dsize ).';' : '';
            $d_lineh       = ( $dlineh !='' ) ? ' line-height:'.esc_attr( $dlineh ).';' : '';
            $descstyle    = ( $d_color   !='' || $d_size !='' || $d_lineh !='' ) ? ' style="'.$d_color.$d_size.$d_lineh.'"' : '';
            $output .= '<h1 data-wow-delay="0.5s" data-wow-duration="3s" class="hs-line-1 wow fadeInUp" '.$descstyle.'>'. $description . '</h1>';
          }
					$output .= ''.do_shortcode( $content ).'';
				$output .= '</div>';
			$output .= '</div>';
			if ($scroll_down_link != ''){ $output .= '<a href="'. $scroll_down_link . '" data-start="display: block" data-100-start="display: none" class="btn-scroll-down scroll"></a>'; }
		$output .= ' </section>';

	return $output;
} add_shortcode('vc_hero_three', 'theme_vc_hero_three');

/*-----------------------------------------------------------------------------------*/
/*	product right
/*-----------------------------------------------------------------------------------*/

function theme_vc_about( $atts, $content = null ) {
    extract( shortcode_atts(array(
		"section_id"         	=> '',
		"fact_align"         	=> 'c',
		"heading"      			=> '',
		"author"      			=> '',
		"facts"     			=> 'show',
		"about"     			=> 'show',
		"progress"     			=> 'show',
		"progress_description"  => '',
		"facts_heading"     	=> '',
		"fact_values"     		=> '',
		"icon_type"     		=> 'd',
		"icon"     				=> '',
		"number"     			=> '',
		"name"     				=> '',
		"progress_values"     	=> '',
		"progress_name"     	=> '',
		"progress_number"     	=> '',
		"acss"     				=> '',
		"fcss"     				=> '',
		"pcss"     				=> '',
		"fhc"     				=> '',
		"abg"     				=> '',
		"fic"     				=> '',
		"fnc"     				=> '',
		"ftc"     				=> '',
		"fbg"     				=> '',
		"pbg"     				=> '',
		"fhg"     				=> '',
		"fdg"     				=> '',
		"fig"     				=> '',
		"ahc"     				=> '',
		"adc"     				=> '',
		"aac"     				=> '',
    "tcolor"            => '',
    "tsize"             => '',
    "tlineh"            => '',
    "dcolor"            => '',
    "dsize"             => '',
    "dlineh"            => '',
    "fcolor"            => '',
    "fsize"             => '',
    "flineh"            => '',
    "pcolor"            => '',
    "psize"             => '',
    "plineh"            => '',
	), $atts) );

	$id 			= ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$aboutcss 		= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $acss, ' ' ),  $atts );
	$factcss 		= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $fcss, ' ' ),  $atts );
	$progresscss	= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $pcss, ' ' ),  $atts );

	$output = '';
	$output .= '<style>';

		$output .= '.nt-facts-section h4{color:'. $fhc .' !important;}';
		$output .= '.nt-facts-section .facts-icon{color:'. $fic .' !important;}';
		$output .= '.nt-facts-section .focus-number{color:'. $fnc .' !important;}';
		$output .= '.nt-facts-section .fact-desc{color:'. $ftc .' !important;}';
		$output .= '.nt-progress-section h3 {color:'. $fhg .' !important;}';
		$output .= '.nt-progress-section blockquote {color:'. $fdg .' !important;}';
		$output .= '.nt-progress-section .progress-box .progress-bar {background-color:'. $fig .' !important;}';
		$output .= '.nt-about-section h3 {color:'. $ahc .' !important;}';
		$output .= '.nt-about-section blockquote p {color:'. $adc .' !important;}';
		$output .= '.nt-about-section .about-quote-author {color:'. $aac .' !important;}';

	$output .= '</style>';

	$output .= '<section '. $id . '>';


	if ($about == 'show'){
		$output .= '<div  class="nt-about-section '. $aboutcss . '">';
			$output .= '<div class="container">';

				$output .= ' <div class="row mt-40 mt-xs-20">';
					$output .= '<div class="col-md-12 text-center">';

						$output .= '<h3 >'. $heading . '</h3>';
					$output .= '</div>';
				$output .= '</div>';

				$output .= '<div class="row mt-60 mt-xs-30">';
					$output .= '<div class="col-md-8 col-md-offset-2 text-center">';

					$output .= '<blockquote data-wow-delay="0.1s" data-wow-duration="1s" class="about-quote wow fadeInUp">';

						$output .= '<p >'. do_shortcode($content) . '</p>';
						if ($author != ''){ $output .= '<footer class="about-quote-author">'. $author . '</footer>'; }
					$output .= '</blockquote>';

					$output .= '</div>';
				$output .= '</div>';

			$output .= '</div>';
		$output .= '</div>';
	}

	if ($facts == 'show'){

		$align 			= ($fact_align == 'c') ? 'center' : 'text-center-off';
		$fact_values 	= (array) vc_param_group_parse_atts($fact_values);

        $output .= ' <div id="facts" class="small-section bg-light nt-facts-section '. $factcss . '">';
           $output .= '<div class="container">';
             $output .= '<div class="row">';
               $output .= '<div class="col-md-12">';

                 $output .= '<h4 class="alt-font" >'. $facts_heading . '</h4>';
               $output .= '</div>';
             $output .= '</div>';
             $output .= '<div class="row mt-60">';

				foreach ( $fact_values as $item ) {
					$output .= '<div class="col-md-3 col-sm-6 '. $align . '">';
						$output .= '<div class="fact-item">';
							$output .= '<div class="fact-number">';

								if ( isset($item['icon_type']) == "d" || isset($item['icon_type']) == "" ) {
									$output .= '<span class="icon-'.$item['icon'].' facts-icon"></span>';
								} elseif(isset($item['icon_type']) == "iconlist") {
									$output .= '<span class="'.$item['icon_list'].' facts-icon"></span>';
								}else{
                                    $output .= '<span class="'.$item['icon'].' facts-icon"></span>';
                                }
								$output .= '<span class="focus-number">'.$item['number'].'</span></div>';
								$output .= '<h5 class="fact-desc alt-font">'.$item['name'].'</h5>';

						$output .= '</div>';
					$output .= ' </div>';
				} // end fact_values

             $output .= '</div>';
          $output .= ' </div>';
         $output .= '</div>';
		}

		if ($progress == 'show'){

			$progress_values 	= (array) vc_param_group_parse_atts($progress_values);
			$number 			= ($progress_description != '') ? '6' : '12';

			$output .= '<div class="nt-progress-section '. $progresscss . '">';
			$output .= '<div class="container">';
				$output .= '<div class="row mt-80 mt-xs-40">';

				$output .= '<div class="col-sm-'. $number . '">';
				 $output .= '<blockquote class="about-quote">';

					$output .= '<p >'. $progress_description . '</p>';
				  $output .= '</blockquote>';
				$output .= '</div>';

				$output .= '<div class="col-sm-'. $number . ' mt-xs-40">';
				foreach ( $progress_values as $item ) {
				  $output .= '<div class="progress-box">';
					$output .= '<div role="progressbar" data-progress="'.$item['progress_number'].'" class="progress-bar" style="width: '.$item['progress_number'].'%;">'.$item['progress_name'].' <span> % '.$item['progress_number'].'</span></div>';
				  $output .= '</div>';
				}
				$output .= '</div>';

				$output .= '</div>'; //end row
			$output .= '</div>'; //end container
			$output .= '</div>'; //end container-first
		}

      $output .= '</section>';

return $output;
}
add_shortcode('vc_about', 'theme_vc_about');


/*-----------------------------------------------------------------------------------*/
/*	service
/*-----------------------------------------------------------------------------------*/

function theme_vc_service( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'section_id' 		=> '',
		'css' 				=> '',
		'heading' 			=> '',
		'description' 		=> '',
		'values'         	=> '',
		'item_description'  => '',
		'icon_type'   		=> 'd',
		'icon_list'   		=> 'd',
		'shc'   			=> '',
		'sdc'   			=> '',
		'sibc'   			=> '',
		'sihbc'   			=> '',
		'siic'   			=> '',
		'sihc'   			=> '',
		'sidc'   			=> '',
		'icon'   			=> '',
		'name'   			=> '',
    "tcolor"            => '',
    "tsize"             => '',
    "tlineh"            => '',
    "dcolor"            => '',
    "dsize"             => '',
    "dlineh"            => '',
    "icolor"            => '',
    "isize"             => '',
    "ilineh"            => '',
    "incolor"            => '',
    "insize"             => '',
    "inlineh"            => '',
    "idcolor"            => '',
    "idsize"             => '',
    "idlineh"            => '',
    ), $atts ) );

	$values 	= (array) vc_param_group_parse_atts($values);
	$id 		= ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$css		= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ),  $atts );

	$output = '';
	$output .= '<style>';

		$output .= '.nt-services-section h3{color:'. $shc .' !important;}';
		$output .= '.nt-services-section .desc{color:'. $sdc .' !important;}';
		$output .= '.nt-services-section .service-item{border-color:'. $sibc .' !important;}';
		$output .= '.nt-services-section .service-item:hover{border-color:'. $sihbc .' !important;}';
		$output .= '.nt-services-section .service-item i{color:'. $siic .' !important;}';
		$output .= '.nt-services-section .service-item h5{color:'. $sihc .' !important;}';
		$output .= '.nt-services-section .service-item p{color:'. $sidc .' !important;}';


	$output .= '</style>';

	$output .= '<section '.$id.' class="nt-services-section '.$css.'">';
       $output .= '<div class="container">';

		if($heading != ''){
          $output .= '<div class="row mt-40 mt-xs-20">';
            $output .= '<div class="col-md-12 text-center">';
              $output .= '<h3 >'.$heading.'</h3>';
            $output .= '</div>';
          $output .= '</div>';
		}
		if($description != ''){
		   $output .= '<div class="row">';
             $output .= '<div class="col-md-8 col-md-offset-2 text-center mt-30 mt-xs-10">';
              $output .= ' <p class="desc">'.$description.'</p>';
             $output .= '</div>';
           $output .= '</div>';
		}

		$output .= '<div data-wow-delay="0.1s" data-wow-duration="2s" class="row mt-60 mt-xs-30 wow fadeIn">';

			foreach ( $values as $v ) {
				$output .= '<div class="col-sm-4 text-center">';
					$output .= '<div class="service-item">';

            if ( isset($v['icon_type']) == "d" ) {
              $output .= '<i class="icon-'.$v['icon'].'"></i>';
            } elseif(isset($v['icon_type']) == "iconlist") {
              $output .= '<i class="'.$v['icon_list'].'"></i>';
            }else{
              $output .= '<i class="'.$v['icon'].'"></i>';
            }
						$output .= '<h5 class="alt-font" >'.$v['name'].'</h5>';
						$output .= '<div class="service-desc">';
							$output .= '<p>'.$v['item_description'].'</p>';
						$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';
			} // end values

		$output .= '</div>'; // end items

        $output .= '</div>';
	$output .= '</section>';
	return $output;
}

add_shortcode('vc_service', 'theme_vc_service');


/*-----------------------------------------------------------------------------------*/
/*	portfolio
/*-----------------------------------------------------------------------------------*/

function theme_vc_portfolio( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"section_id"     	=> '',
	"css"     			=> '',
	"bottom"     		=> 's',
	"heading"      	 	=> '',
	"description"       => '',
	"cat_display"       => '',
	"bottomheading"     => '',
	"bottomdescription" => '',
	"buttonlink"      	=> '',
	"buttontext"      	=> '',
	'order'      	 	=> 'ASC',
	'orderby'     	 	=> 'date',
	'posts'     	 	=> '12',
	'column'     	 	=> '3',
	'phc'   			=> '',
	'pdc'   			=> '',
	'pibc'   			=> '',
	'pihbc'   			=> '',
	'pihabc'   			=> '',
	'piic'   			=> '',
	'pihc'   			=> '',
	'pipdc'   			=> '',
	'pbgdc'   			=> '',
	'pidc'   			=> '',
	'plinktype'   			=> 'd',
	'customurl'   			=> '',
	'btntarget'   			=> '',
  "tcolor"            => '',
  "tsize"             => '',
  "tlineh"            => '',
  "dcolor"            => '',
  "dsize"             => '',
  "dlineh"            => '',
  "pcolor"            => '',
  "pize"             => '',
  "plineh"            => '',
	), $atts) );

	$output 	= '';
	$output .= '<style>';

		$output .= '.nt-portfolio-section h3{color:'. $phc .' !important;}';
		$output .= '.nt-portfolio-section .desc{color:'. $pdc .' !important;}';
		$output .= '.nt-portfolio-section .filter li a{color:'. $pibc .' !important;}';
		$output .= '.nt-portfolio-section .filter li a:hover{border-color:'. $pihbc .' !important;}';
		$output .= '.nt-portfolio-section .filter li.active a{border-color:'. $pihabc .' !important;}';
		$output .= '.nt-portfolio-section .small-section h4{color:'. $piic .' !important;}';
		$output .= '.nt-portfolio-section .small-section h5{color:'. $pihc .' !important;}';
		$output .= '.nt-portfolio-section .small-section .btn-coffee.btn-border{border-color:'. $pipdc .' !important;}';
		$output .= '.nt-portfolio-section .small-section .btn-coffee.btn-border{background-color:'. $pbgdc .' !important;}';
		$output .= '.nt-portfolio-section .small-section .btn-coffee.btn-border{color:'. $pidc .' !important;}';

	$output .= '</style>';

	$id 		= ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$css		= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ),  $atts );
	$pccategor 	= get_terms('portfolio_category');

	wp_enqueue_script('isotope');
	wp_enqueue_script('exline-custom-portfolio');

	global $wp_query;
	$paged = get_query_var('page') ? get_query_var('page') : 1;
	$port_args = array(
	'post_type' 		=> 'portfolio',
	'post_status' 		=> 'publish',
	'orderby' 			=> $orderby,
	'posts_per_page'    => $posts,
	'order' 			=> $order,
	'paged' 			=> $paged
	);
	?>

  <section <?php echo ($id); ?> class="bg-light pb-60 section-portfilo nt-portfolio-section <?php echo ($css); ?>">
        <div class="container">
          <div class="row mt-40 mt-xs-20">
            <div class="col-md-12 text-center">

              <h3 ><?php echo ($heading); ?></h3>
            </div>
          </div>
          <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center mt-30 mt-xs-10">

              <p class="desc" ><?php echo ($description); ?></p>
            </div>
          </div>
        </div>

      <?php 	if($cat_display !='hide'): ?>
        <?php 	if($pccategor): ?>

			<ul class="filter text-center mt-60 mt-xs-30">
				<li><a href="#" data-filter="*" class="active"> <?php _e('All works','exline') ?></a></li>
				<?php foreach($pccategor as $portfolio_category): ?>
					<li><a href="#" data-filter=".<?php echo ($portfolio_category->slug); ?>" ><?php echo ($portfolio_category->name); ?></a></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<?php endif; ?>

		<?php
		$wp_query = new WP_Query($port_args);
		if( have_posts() ) : ?>
        <div class="container">
          <div data-wow-delay="0.1s" data-wow-duration="2s" class="work-container mt-40 mt-xs-20 wow fadeIn">
            <div class="row-off">

					<?php
						while ( $wp_query->have_posts() ) :
						$wp_query->the_post();
						$terms = get_the_terms( get_the_ID(), 'portfolio_category' );
					?>
						<div class="col-md-<?php echo ($column); ?> col-sm-4 col-xs-12 <?php if($terms) : foreach ($terms as $term) { echo 'work-item '.$term->slug.' '; } endif; ?>">

							<div class="figure effect-hover">

								<?php  if ( has_post_thumbnail()) {
									$att		=	get_post_thumbnail_id();
									$image_src 	= 	wp_get_attachment_image_src( $att, 'full' );
									$image_src 	= 	$image_src[0]; ?>
									<img src="<?php echo esc_url($image_src); ?>" class="img-responsive" alt="alt" title="title"/>
								<?php } ?>

								<div class="figcaption">

									<h5 class="alt-font"><?php the_title(); ?></h5>

									<p ><?php echo substr(get_the_excerpt(), 0, 60); ?></p>
								</div>

								<?php
                $costum_url = get_post_meta( get_the_ID(), 'exline_custom_url', true );

									$exline_embed = rwmb_meta('exline_video_embed');
									if (  $plinktype =='d'):
									if ( 'video' == get_post_format()  && $exline_embed !='' ):
								?>
   								<a href="<?php echo esc_url($exline_embed); ?>" class="work-gallery  mfp-iframe"><?php _e('View more','exline') ?></a>
   								<?php else : ?>
   								<a href="<?php echo esc_url($image_src); ?>" class="work-gallery mfp-image"><?php _e('View more','exline') ?></a>
   								<?php endif; ?>
								<?php elseif($plinktype =='p'): ?>
                   <a href="<?php echo esc_url( get_permalink() ); ?>" class="link" ><?php _e('View more','exline') ?></a>
                 <?php elseif($plinktype =='c'): ?>
                     <a href="<?php echo esc_url( $costum_url ); ?>" class="link" ><?php _e('View more','exline') ?></a>
                <?php endif; ?>

							</div>
						</div>
					<?php 	endwhile; ?>
				</div>
			</div>
        </div>
		<?php	endif; ?>

		<?php  if ( $bottom !='h' || $bottom =='' ) { ?>
        <!-- Call to action-->
        <div class="small-section bg-light call-to-action pb-0 <?php echo ($css); ?>">
			<div class="container">
				<div class="row">
				  <div class="col-sm-7">
					<h4 class="alt-font"><?php echo ($bottomheading); ?></h4>
					<h5><?php echo ($bottomdescription); ?></h5>
				  </div>
				  <div class="col-sm-5 text-center"><a href="<?php echo ($buttonlink); ?>" target="<?php echo esc_attr($btntarget); ?>" class="btn btn-coffee btn-border btn-large mt-20"><?php echo ($buttontext); ?></a></div>
				</div>
			</div>
		</div>
		<?php	} ?>
      </section>


	<?php wp_reset_query();  ?>
	<?php
	return $output;
}
add_shortcode('vc_portfolio', 'theme_vc_portfolio');


/*-----------------------------------------------------------------------------------*/
/*	team
/*-----------------------------------------------------------------------------------*/

function theme_vc_team( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'heading' 		=> '',
		'css' 			=> '',
		'section_id' 	=> '',
		'description' 	=> '',
		'values'        => '',
		'auto'        => 'false',
		'url'   		=> '',
		'icon'   		=> '',
		'thc'   		=> '',
		'tdc'   		=> '',

    ), $atts ) );

	$id 		= ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$css		= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ),  $atts );

	$output = '';
	$output .= '<style>';

		$output .= '.nt-team-section h3{color:'. $thc .' !important;}';
		$output .= '.nt-team-section .desc{color:'. $tdc .' !important;}';

	$output .= '</style>';

	$output .= '<section '.$id.' class="pb-40 nt-team-section '.$css.'" data-auto="'.esc_attr($auto).'">';
		$output .= '<div class="container">';

			if($heading != ''){
			  $output .= '<div class="row mt-40 mt-xs-20">';
				$output .= '<div class="col-md-12 text-center">';
				  $output .= '<h3 >'.$heading.'</h3>';
				$output .= '</div>';
			  $output .= '</div>';
			}

			if($description != ''){
				$output .= '<div class="row">';
					$output .= '<div class="col-md-8 col-md-offset-2 text-center mt-30 mt-xs-10">';
						$output .= ' <p class="desc" >'.$description.'</p>';
					$output .= '</div>';
				$output .= '</div>';
			}

			$output .= '<div class="row mt-80 mt-xs-40 mb-80 mb-xs-40 team-slider">';
			   $output .= ''. do_shortcode($content) . '';
			$output .= '</div>';

		$output .= '</div>';
	$output .= '</section>';
	return $output;
}

add_shortcode('vc_team', 'theme_vc_team');

/*-----------------------------------------------------------------------------------*/
/*	team item
/*-----------------------------------------------------------------------------------*/

function theme_vc_team_item( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'team_img' 	=> '',
		'name' 		=> '',
		'values'    => '',
		'url'   	=> '',
		'position'  => '',
		'description'=> '',
      'link'   	=> '',
		'icon'  	 => '',
    "tcolor"            => '',
    "tsize"             => '',
    "tlineh"            => '',
    "dcolor"            => '',
    "dsize"             => '',
    "dlineh"            => '',
    ), $atts ) );

	$team_img_url 	= wp_get_attachment_url( $team_img,'full' );
	$image 			= exline_aq_resize( $team_img_url, 200, 200, true );
	$values 		= (array) vc_param_group_parse_atts($values);

	$link 			= ( $link == '||' ) ? '' : $link;
	$link 			= vc_build_link( $link );
	$a_href 		= $link['url'];
	$a_title 		= $link['title'];
	$a_target 		= $link['target'];

	$link_a_target 	= ($a_target != '') ? 'target="'. esc_attr($a_target) . '" ' : '';
	$link_a_href 	= ($a_href != '')   ? 'href="'. esc_url($a_href) . '" ' : '';
	$link_a_title 	= ($a_title != '')   ? ''. esc_html($a_title) . '' : '';

	$output = '';
	$output .= ' <div class="col-sm-12">';
		$output .= '<figure class="team-item">';

			if ($image != ''){
				if ( $a_title !=''){  $output .= '<a '. $link_a_href . ' '. $link_a_target . '>'; }
					$output .= '<img src="'.$image.'"  alt="' . get_the_title() . '" class=" img-circle">';
				if ( $a_title !=''){  $output .= '</a>'; }
			}

			$output .= '<div class="social-links team-social">';
				foreach ( $values as $v ) {
					$output .= '<a href="'.$v['url'].'" title="Facebook" target="_blank">';
					$output .= '<i class="fa fa-'.$v['icon'].'"></i>';
					$output .= ' </a>';
				}
			$output .= '</div>';

			$output .= '<figcaption>';
      $t_color       = ( $tcolor !='' ) ? ' color:'.esc_attr( $tcolor ).';' : '';
      $t_size        = ( $tsize  !='' ) ? ' font-size:'.esc_attr( $tsize ).';' : '';
      $t_lineh       = ( $tlineh !='' ) ? ' line-height:'.esc_attr( $tlineh ).';' : '';
      $titlestyle    = ( $t_color   !='' || $t_size !='' || $t_lineh !='' ) ? ' style="'.$t_color.$t_size.$t_lineh.'"' : '';
				$output .= '<h5 class="alt-font" '.$titlestyle.'>';
					if ($name != ''){  $output .= ''. esc_html($name) . '';}
					if ($position != ''){ $output .= '<small> '. esc_html($position) . '</small>'; }
				$output .= ' </h5>';
        $d_color       = ( $dcolor !='' ) ? ' color:'.esc_attr( $dcolor ).';' : '';
        $d_size        = ( $dsize  !='' ) ? ' font-size:'.esc_attr( $dsize ).';' : '';
        $d_lineh       = ( $dlineh !='' ) ? ' line-height:'.esc_attr( $dlineh ).';' : '';
        $descstyle    = ( $d_color   !='' || $d_size !='' || $d_lineh !='' ) ? ' style="'.$d_color.$d_size.$d_lineh.'"' : '';
				$output .= '<p '.$descstyle.'>'. esc_html($description) . '</p>';
			$output .= '</figcaption>';

		$output .= '</figure>';
	$output .= '</div>';
	return $output;

}

add_shortcode('vc_team_item', 'theme_vc_team_item');

/*-----------------------------------------------------------------------------------*/
/*	testimonials
/*-----------------------------------------------------------------------------------*/

function theme_vc_testimotal( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'section_id' 	=> '',
		'css' 			=> '',
		'heading' 		=> '',
		'name' 			=> '',
		'values'        => '',
		'description'   => ''
    ), $atts ) );

	$values 	= (array) vc_param_group_parse_atts($values);
	$id 		= ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$css		= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ),  $atts );

	$output = '';
	$output .= '<div '. $id . ' class="fullwidth-testimotal-slider bg-dark-80 pt-100 pb-100 nt-testimonial-section '. $css . '">';
	foreach ( $values as $v ) {
         $output .= ' <div>';
            $output .= '<div class="container">';
              $output .= '<div class="row">';
               $output .= ' <div class="col-md-8 col-md-offset-2 text-center">';
				$output .= '<div class="section-icon"><span class="icon-quote"></span></div>';
				$output .= '<h3 class="alt-font">'. esc_html($heading) . '</h3>';

					$output .= '<blockquote class="testimonial">';
					$output .= '<p>'.$v['description'].'</p>';
					$output .= '<footer class="testimonial-author">'.$v['name'].'</footer>';
					$output .= ' </blockquote>';

               $output .= ' </div>';
              $output .= '</div>';
            $output .= '</div>';
          $output .= '</div>';
	}
       $output .= ' </div>';
	return $output;
}

add_shortcode('vc_testimotal', 'theme_vc_testimotal');

/*-----------------------------------------------------------------------------------*/
/*	logos
/*-----------------------------------------------------------------------------------*/

function theme_vc_logos( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'images' 		=> '',
		'thumb_size' 	=> 'exline-logos',
		'css' 			=> 'exline-logos',
    ), $atts ) );

	$logo_images 	= explode(",", $images);
	$css			= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ),  $atts );

	$output = '';
	 $output .= '<div class="small-section pt-40 pb-40 white '. $css . '">';
	  $output .= ' <div class="container">';
		 $output .= '<div class="row">';
		   $output .= '<div class="col-md-10 col-md-offset-1">';
			 $output .= '<div class="small-carousel owl-carousel">';
				$i = 0;
				foreach($logo_images as $single_image) {
					$img_size = '';
					$img_size = wpb_getImageBySize(array( 'attach_id' => (int)$single_image, 'thumb_size' => $thumb_size ));
					$output .= '<div class="logo-item">';
					$output .= $img_size['thumbnail'];
					$output .= ' </div>';
				$i++; }
			 $output .= '</div>';
		   $output .= '</div>';
		 $output .= '</div>';
	   $output .= '</div>';
	 $output .= '</div>';
	 $output .= '<hr>';
	return $output;
}

add_shortcode('vc_logos', 'theme_vc_logos');

/*-----------------------------------------------------------------------------------*/
/*	price table
/*-----------------------------------------------------------------------------------*/

function theme_vc_price_table($atts){
	extract(shortcode_atts(array(
       	'css'      			=> '',
       	'orderby'      		=> 'date',
       	'order'      		=> 'DESC',
       	'post_number'      	=> '3',
       	'categories' 		=> 'all',
		'section_id' 		=> '',
		'heading' 			=> '',
		'slogan' 			=> '',
		'prhc' 				=> '',
		'prdc' 				=> '',
		'pribc' 			=> '',
		'prabc' 			=> '',
    ), $atts));

	$css	= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ),  $atts );
	$id 	= ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';

	$p_args 	= 	array(
		'post_type' 		=> 'price',
		'posts_per_page' 	=> $post_number,
		'order' 			=> $order,
		'orderby' 			=> $orderby,
		'post_status' 		=> 'publish'
	);

    if($categories != 'all'){
    	$str = $categories;
    	$arr = explode(',', $str);
		$p_args['tax_query'][] = array(
		'taxonomy' 	=> 'price_category',
		'field' 	=> 'slug',
		'terms' 	=> $arr );
	}

	$output = '';
	$output .= '<style>';

		$output .= '.nt-price-section h3{color:'. $prhc .' !important;}';
		$output .= '.nt-price-section .desc{color:'. $prdc .' !important;}';
		$output .= '.nt-price-section .pricing-main .pricing-inner{color:'. $prabc .' !important;}';
		$output .= '.nt-price-section .pricing-inner,.pricing-list li:first-child,.pricing-list li,.pricing-button,.pricing-inner:hover .pricing-icon, .pricing-inner:hover .pricing-title{border-color:'. $pribc .' !important;}';

	$output .= '</style>';

	$output .= '<section '.$id.' class="price-container nt-price-section '.$css.' ">';
        $output .= '<div class="container">';

			if($heading != ''){
				$output .= '<div class="row mt-40 mt-xs-20">';
					$output .= '<div class="col-md-12 text-center">';
						$output .= '<h3>'.$heading.'</h3>';
					$output .= '</div>';
				$output .= '</div>';
			}
			if($slogan != ''){
				$output .= '<div class="row">';
					$output .= '<div class="col-md-8 col-md-offset-2 text-center mt-30 mt-xs-10">';
						$output .= ' <p class="desc">'.$slogan.'</p>';
					$output .= '</div>';
				$output .= '</div>';
			}

			$output .= ' <div data-wow-delay="0.1s" data-wow-duration="1s" class="row mt-80 mt-xs-40 wow zoomIn">';

				$nt_sawmill_price_query = new WP_Query($p_args);
				if( $nt_sawmill_price_query->have_posts() ) :
				while ($nt_sawmill_price_query->have_posts()) :
				$nt_sawmill_price_query->the_post();

					$price_column = get_post_meta( get_the_ID(), 'exline_price_column', true );
					$offsetcolumn = get_post_meta( get_the_ID(), 'exline_offset', true );
					$table_curr   =	get_post_meta( get_the_ID(), 'exline_table_currency', true );
					$best 		  = get_post_meta( get_the_ID(), 'exline_best', true );
					$table_icon   = get_post_meta( get_the_ID(), 'exline_table_icon', true );
					$table_price  = get_post_meta( get_the_ID(), 'exline_table_price', true );
					$table_time   = get_post_meta( get_the_ID(), 'exline_table_time', true );
					$table_name   = get_post_meta( get_the_ID(), 'exline_table_name', true );
					$table_slogan = get_post_meta( get_the_ID(), 'exline_table_slogan', true );
					$table_link   = get_post_meta( get_the_ID(), 'exline_table_link', true );
					$table_text   = get_post_meta( get_the_ID(), 'exline_table_link_text', true );
					$contents     = get_post_meta( get_the_ID(), 'exline_features_list', true );
					$featured     = ($best == 'yes') ? 'pricing-main' : '';
					$price_clmn   =  $price_column  ? $price_column : '4';

					$output .= '<div class="col-sm-6 col-md-'.$price_clmn.' '.$featured.' col-md-offset-'.$offsetcolumn.'">';
					$output .= ' <div class="pricing-item">';
					$output .= '<div class="pricing-inner">';
					$output .= '<div class="pricing-content">';
					$output .= '<div class="pricing-icon"><i class="icon-'.$table_icon.'"></i></div>';
					$output .= '<div class="pricing-title">'.$table_name.'</div>';
					$output .= '<div class="pricing-features alt-font">';

					if($contents) {
					$output .= '<ul class="sf-list pricing-list">';
					foreach ($contents as $contentitem) { $output .= '<li>'.$contentitem.'</li>'; }
					$output .= '</ul>';
					}

					$output .= '</div>';
					$output .= '<div class="pricing-cost"><sup>'.$table_curr.'</sup>'.$table_price.'</div>';
					$output .= '<div class="pricing-period">'.$table_time.'</div>';
					$output .= ' <div class="pricing-button"><a href="'.$table_link.'" class="btn btn-coffee">'.$table_text.'</a></div>';
					$output .= '</div>';
					$output .= '</div>';
					$output .= '</div>';
					$output .= '</div>';
			   endwhile;
			   endif;
			   wp_reset_postdata();

			$output .= '</div>';
		$output .= '</div>';
	$output .= '</section>';

	return $output;
}
add_shortcode('vc_price_table', 'theme_vc_price_table');

/*-----------------------------------------------------------------------------------*/
/*	Latest Blog
/*-----------------------------------------------------------------------------------*/

function theme_vc_blog($atts){
	extract(shortcode_atts(array(
       	'css'    		=> '',
       	'section_id'    => '',
       	'order'      	=> 'DESC',
       	'orderby'      	=> 'date',
       	'posts'      	=> '3',
       	'categories' 	=> 'all',
		'excerpt_size' 	=> '130',
		'buttonlink' 	=> '',
		'buttontext' 	=> '',
		'slogan' 		=> '',
		'heading' 		=> ''
    ), $atts));

	$css	= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ),  $atts );

    global $post;
	$args = array(
		'post_type' => 'post', 'posts_per_page' => $posts, 'order' => $order, 'orderby' => $orderby, 'post_status'=> 'publish'
    );

    if($categories != 'all'){
    	$str = $categories;
    	$arr = explode(',', $str);
		$args['tax_query'][] = array( 'taxonomy' 	=> 'category', 'field' 	=> 'slug', 'terms' 	=> $arr );
	}
    query_posts( $args );

	$id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$columnclass = ($slogan != '') ? 'mt-40 mt-xs-20' : '';

    $output = '';
	$output .= ' <section ' . $id . ' class="bg-light nt-blog-section '.$css.'">';
		$output .= '<div class="container">';

			if($heading != ''){
				$output .= '<div class="row ' . $columnclass . '">';
					$output .= ' <div class="col-md-12 text-center">';
						$output .= '<h3>' . $heading . '</h3>';
					$output .= ' </div>';
				$output .= '</div>';
			}

			if($slogan != ''){
				$output .= '<div class="row">';
					$output .= '<div class="col-md-8 col-md-offset-2 text-center mt-30 mt-xs-10">';
						$output .= '<p>'.$slogan.'</p>';
					$output .= '</div>';
				$output .= '</div>';
			}

			$output .= ' <div class="row blog-masonry mt-60 mt-xs-10">';

				$exline_blog_query = new WP_Query($args);
				if( $exline_blog_query->have_posts() ) :
					while ($exline_blog_query->have_posts()) : $exline_blog_query->the_post();
						$output .= '<div class="col-md-4 col-sm-6 post-masonry blog-post">';
						$output .= '<a href="'.get_permalink().'">';
						$img_url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ,'full' ); //get full URL to image (use "large" or "medium" if the images too big)
						$image = exline_aq_resize( $img_url, 360,240, true,true,true ); //resize & crop the image
						$output .= ' <div class="post-thumbnail"><img src="'. $image .'" alt="' . get_the_title() . '" class="resp"></div>';
						$output .= '<div class="post-content">';
							$output .= ' <h4 class="post-title">' . get_the_title() . '</h4>';
							$output .= '<div class="date-post">' . get_the_time('F j, Y') . '</div>';
							$output .= '<p>' . substr(get_the_excerpt(), 0, $excerpt_size) . '</p>';
						$output .= '</div>';
						$output .= '</a>';
						$output .= '</div>';
					endwhile;
					wp_reset_query();
				endif;

			$output .= ' </div>'; // row end

	if($buttonlink != ''){
		$output .= '<div class="row mt-60">';
			$output .= ' <div class="col-md-12 text-center"><a href="' . $buttonlink . '" class="btn btn-coffee btn-border">' . $buttontext . '</a></div>';
		$output .= '</div>';
	}

	$output .= '</div>';
	$output .= '</section>';
	return $output;
}
add_shortcode('vc_blog', 'theme_vc_blog');


/*-----------------------------------------------------------------------------------*/
/*	subscribe
/*-----------------------------------------------------------------------------------*/

function theme_vc_subscribe( $atts, $content = null ) {
    extract( shortcode_atts(array(
		"css"      		=> '',
		"section_id"    => '',
		"heading"      	=> '',
		"subrhc"      	=> '',
		"subrdc"      	=> '',
		"subfrdc"      	=> '',
		"subfbtnbg"     => '',
		"subfbtnt"     => '',
	), $atts) );

	$id 	= ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$css	= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ),  $atts );

	$output = '';
	$output .= '<style>';

		$output .= '.nt-subscribe-section h3{color:'. $subrhc .' !important;}';
		$output .= '.nt-subscribe-section .desc{color:'. $subrdc .' !important;}';
		$output .= '.nt-subscribe-section .form input.newsletter-input{border-color:'. $subfrdc .' !important;}';
		$output .= '.nt-subscribe-section .form input[type=submit] {background-color:'. $subfbtnbg .' !important;}';
		$output .= '.nt-subscribe-section .form input[type=submit] {color:'. $subfbtnbg .' !important;}';

	$output .= '</style>';

	$output .= '<div '.$id.' class="small-section bg-dark-80 nt-subscribe-section '.$css.'">';
          $output .= '<div class="container">';
            $output .= '<div id="mailchimp" class="form">';
              $output .= '<div class="row">';
               $output .= ' <div class="col-md-8 col-md-offset-2 text-center">';
                  $output .= '<h4 class="alt-font newsletter-title mb-50">'. $heading . '</h4>';
                    $output .= ''. do_shortcode($content) . '';
                $output .= '</div>';
              $output .= '</div>';
            $output .= '</div>';
          $output .= '</div>';
        $output .= '</div>';
	return $output;
}
add_shortcode('vc_subscribe', 'theme_vc_subscribe');

/*-----------------------------------------------------------------------------------*/
/*	subscribe
/*-----------------------------------------------------------------------------------*/

function theme_vc_contact( $atts, $content = null ) {
    extract( shortcode_atts(array(
		"css"      		 		 => '',
		"section_id"      	 => '',
		"heading"      		 => '',
		"phone"      			 => '',
		"phoneurl"      			 => '',
		"phonetarget"      			 => '',
		"adress"      			 => '',
		"mail"      			 => '',
		"mailurl"      		 => '',
		"mailtarget"      		 => '',
		"map"      			 	 => 'show',
		"map_adress"      		 => 'Belt Parkway, Queens, NY, United States',
		"opentext"      		 => '',
		"closetext"      		 => '',
		"heading"      			 => '',
		"description"            => '',
		"crhc"            		=> '',
		"crdc"            		=> '',
		"cmbg"            		=> '',
		"cmtc"            		=> '',
	), $atts) );

	$id 	= ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$css	= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ),  $atts );

	$output = '';
	$output .= '<style>';

		$output .= '.nt-contact-section h3{color:'. $crhc .' !important;}';
		$output .= '.nt-contact-section .desc{color:'. $crdc .' !important;}';
		$output .= '.nt-contact-section .map-section{background-color:'. $cmbg .' !important;}';
		$output .= '.nt-contact-section .toggle-text{background-color:'. $cmtc .' !important;}';

	$output .= '</style>';

	$output .= '<section '.$id.' class="pt-0 nt-contact-section '.$css.'">';
		$output .= '<div class="container">';

				$output .= '<div class="row">';
					$output .= '<div class="col-md-12 text-center mt-60 mt-xs-30">';
						$output .= '<h3>'. $heading . '</h3>';
					$output .= '</div>';
				$output .= '</div>';

				$output .= '<div class="row mt-20">';
					$output .= '<div class="col-md-8 col-md-offset-2 text-center">';
						$output .= '<p class="desc">'. $description . '</p>';
					$output .= '</div>';
				$output .= '</div>';

				$output .= '<div class="row mt-60 mt-xs-30">';
					$output .= '<div class="col-md-8 col-md-offset-2 text-center">';

						$output .= '<div class="col-sm-4 contact-item"><span class="icon-phone"></span>';
            if($phone !='' or $phoneurl !=''){ $output .= '<a href="'. $phoneurl . '" target="'.$phonetarget.'">'. $phone . '</a>'; }
						$output .= '</div>';

						$output .= '<div class="col-sm-4 contact-item"><span class="icon-map-pin"></span>';
							$output .= '<p>'. $adress . '</p>';
						$output .= '</div>';

						$output .= '<div class="col-sm-4 contact-item"><span class="icon-envelope"></span>';
							if($mail !='' or $mailurl !=''){ $output .= '<a href="'. $mailurl . '" target="'.$mailtarget.'">'. $mail . '</a>'; }
						$output .= '</div>';

					$output .= '</div>';
				$output .= '</div>';

				$output .= '<div class="row">';
					$output .= '<div class="col-md-8 col-md-offset-2 mt-40">';
						$output .= '<div id="contact-form" class="form form-contact">';
							$output .= ''. do_shortcode($content) . '';
						$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';

		$output .= '</div>';

		if($map == 'show'){
			wp_enqueue_script('google-maps-api');
			wp_enqueue_script('gmap3');

			$output .= '<div class="google-map">';
				$output .= '<div id="map-canvas" data-address="'. $map_adress . '"></div>';
				$output .= '<div class="map-section">';
					$output .= ' <div class="map-toggle">';
						$output .= ' <div class="toggle-text alt-font">';
							$output .= ' <div class="toggle-open">'. $opentext . '<i class="fa fa-angle-down"></i></div>';
							$output .= '<div class="toggle-close">'. $closetext . '<i class="fa fa-angle-up"></i></div>';
						$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';
			$output .= '</div>';
		}

	$output .= ' </section>';

	return $output;
}
add_shortcode('vc_contact', 'theme_vc_contact');
