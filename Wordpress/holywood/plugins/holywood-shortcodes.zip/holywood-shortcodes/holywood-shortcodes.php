<?php

/*
Plugin Name: NT Holywood Shortcodes
Plugin URI: http://themeforest.net/user/Ninetheme
Description: Shortcodes for Ninetheme WordPress Themes - NT-Holywood Version
Version: 1.2
Author: Ninetheme
Author URI: http://themeforest.net/user/Ninetheme
*/

require_once plugin_dir_path(__FILE__) . 'aq_resizer.php';

/*-----------------------------------------------------------------------------------*/
/*	header
/*-----------------------------------------------------------------------------------*/

function theme_vc_header( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"logo_url" => '',
	"logo_1x" => '',
	"logo_2x" => '',
	"overlay" => 'show',
	"heading" => '',
	"description" => '',
	"subscribe_heading" => '',
	"target_url" => '',
	"subscribe_button_text" => '',
	"button_left_url" => '',
	"button_left_text" => '',
	"button_right_url" => '',
	"button_right_text" => '',
	"scroll_down_link" => ''

	), $atts) );
	$output = '';

    $imagealt = get_post_meta($logo_1x, '_wp_attachment_image_alt', true);
    $imagealt = $imagealt ? $imagealt : basename ( get_attached_file( $logo_1x ) );
    $imagealt2 = get_post_meta($logo_2x, '_wp_attachment_image_alt', true);
    $imagealt = $imagealt2 ? $imagealt2 : basename ( get_attached_file( $logo_2x ) );

	$logo_1x_url = wp_get_attachment_url( $logo_1x, 'full' );
	$logo_2x_url = wp_get_attachment_url( $logo_2x, 'full' );

	$output .= '<div class="hero">';
	if ($overlay == 'show'){  $output .= '<div class="lj-overlay lj-overlay-color"></div>'; }
    $output .= '<div class="container">';

        if ( 'yes' !=  ot_get_option( 'holywood_use_new_header' ) ) {
         $output .= ' <div class="row">';
            $output .= '<div class="col-sm-4 lj-logo wow fadeInDown">';
				$output .= '<a href="'. esc_url($logo_url) . '">';
					if ($logo_1x_url != ''){ $output .= ' <img src="'. esc_url($logo_1x_url) . '" class="lj-logo-1x" alt="'.$imagealt.'">'; }
					if ($logo_2x_url != ''){ $output .= '<img src="'. esc_url($logo_2x_url) . '" class="lj-logo-2x" alt="'.$imagealt2.'">';  }
				$output .= '</a>';
            $output .= '</div>';
           $output .= ' <div class="col-sm-8 lj-text-button wow fadeInDown">';
              $output .= '<span>'. esc_html($subscribe_heading) . '</span>';
              $output .= '<a href="'. esc_url($target_url) . '">'. esc_html($subscribe_button_text) . '</a>';
            $output .= '</div>';
            $output .= '</div>';
        }

			 $output .= ' <div class="row">';
            $output .= '<div class="col-xs-12 lj-title wow fadeInDown" data-wow-delay="0.5s">';
              $output .= '<h1 class="lj-text-center">'. $heading . '</h1>';
            $output .= '</div>';
            $output .= '</div>';

			 $output .= ' <div class="row">';
           $output .= ' <div class="col-sm-12 col-md-8 col-md-offset-2 lj-title-paragraph wow fadeInDown" data-wow-delay="1s">';
             $output .= ' <p class="lj-text-center">'. $description . '';
            $output .= '</div>';
            $output .= '</div>';

			 $output .= ' <div class="row">';
            $output .= '<div class="col-xs-12 col-sm-8 col-sm-offset-2 lj-buttons wow fadeInUp" data-wow-delay="1.5s">';
			if ($button_left_text != ''){ $output .= '<a href="'. esc_url($button_left_url) . '" class="lj-button-left">'. esc_html($button_left_text) . ' <i class="fa fa-long-arrow-right"></i></a>'; }
			if ($button_right_text != ''){ $output .= '<a href="'. esc_url($button_right_url) . '" class="lj-button-right">'. esc_html($button_right_text) . '</a>'; }
            $output .= '</div>';
            $output .= '</div>';

			 $output .= ' <div class="row">';
            $output .= '<div class="col-sm-12 lj-scroll-down wow fadeInUp" data-wow-delay="2s">';
			if ($scroll_down_link != ''){ $output .= '<a href="'. esc_url($scroll_down_link) . '"><i class="fa fa-chevron-down"></i></a>'; }
            $output .= '</div>';
          $output .= '</div>';

      $output .= '</div>';
 $output .= '</div>';

return $output;
}
add_shortcode('vc_header', 'theme_vc_header');

/*-----------------------------------------------------------------------------------*/
/*	product right
/*-----------------------------------------------------------------------------------*/

function theme_vc_product( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"section_bg_color" => '',
	"right_color" => '',
	"border_right_color" => '',
	"bg_right_color" => '',
	"bg_color" => '',
	"button_color" => '',
	"border_color" => '',
	"section_id" => '',
	"image_position" => 'left',
	"image" => '',
	"heading" => '',
	"values" => '',
	"list_item" => '',
	"icon_item" => 'long-arrow-right',
	"button_left_url" => '',
	"button_left_text" => '',
	"button_right_url" => '',
	"button_right_text" => ''
	), $atts) );

    $imagealt = get_post_meta($image, '_wp_attachment_image_alt', true);
    $imagealt = $imagealt ? $imagealt : basename ( get_attached_file( $image ) );

	$image_url = wp_get_attachment_url( $image, 'events' );
	$values = (array) vc_param_group_parse_atts($values);
	$id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$output = '';
	$output .= '<style>';
	$output .= '#'.$section_id.' .lj-product-button-left {
		border-color: '. esc_attr($border_color) . ';
		background-color: '. esc_attr($bg_color) . ';
		color: '. esc_attr($button_color) . '; }
		';
		$output .= '#'.$section_id.' .lj-product-button-right {
		border-color: '. esc_attr($border_right_color) . ';
		background-color: '. esc_attr($bg_right_color) . ';
		color: '. esc_attr($right_color) . '; }
		';
		$output .= '#'.$section_id.'.product.module {background-color: '. esc_attr($section_bg_color) . '}';
	$output .= '</style>';

	if ($image_position == 'left'){
	$output .= '<div '.$id.' class="product module">';
	} else {
	$output .= '<div '.$id.' class="product product-right module">';
	}
	$output .= '<div class="container">';
	$output .= '<div class="row">';

	if ($image_position == 'left'){
		$output .= '<div class="col-md-5 lj-product-image wow fadeInDown" data-wow-delay="0.5s">';
		if ($image_url != ''){  $output .= '<img src="'. esc_url($image_url) . '" alt="'.$imagealt.'">'; }
		$output .= '</div>';
	}

	$output .= '<div class="col-md-7 lj-product">';
	  $output .= '<h3>'. $heading . '</h3>';
	  $output .= '<p></p>';
	  $output .= ''. $content . '';
	  $output .= '<ul class="lj-product-features fa-ul">';
		foreach ( $values as $v ) { $output .= '<li><i class="fa-li fa fa-'.$v['icon_item'].'"></i>'.$v['list_item'].'</li>'; }
	 $output .= '</ul>';
	if ($button_left_text != ''){ $output .= '<a href="'. esc_url($button_left_url) . '" class="lj-product-button-left">'. esc_html($button_left_text) . ' <i class="fa fa-long-arrow-right"></i></a>';}
	if ($button_right_text != ''){ $output .= '<a href="'. esc_url($button_right_url) . '" class="lj-product-button-right">'. esc_html($button_right_text) . '</a>';}
	$output .= '</div>';

	if ($image_position == 'right'){
		$output .= '<div class="col-md-5 lj-product-image wow fadeInDown" data-wow-delay="0.5s">';
		if ($image_url != ''){  $output .= '<img src="'. esc_url($image_url) . '" alt="'.$imagealt.'">'; }
		$output .= '</div>';
	}
	$output .= '</div>';
	$output .= '</div>';
	$output .= '</div>';


return $output;
}
add_shortcode('vc_product', 'theme_vc_product');

/*-----------------------------------------------------------------------------------*/
/*	parallax
/*-----------------------------------------------------------------------------------*/

function theme_vc_parallax( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"bg_color" => '',
	"button_color" => '',
	"border_color" => '',
	"section_id" => '',
	"heading_color" => '',
	"text_color" => '',
	"description" => '',
	"heading" => '',
	"button_left_url" => '',
	"button_left_text" => ''
	), $atts) );
	$output = '';
	$id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
   $output .= '<div '.$id.' class="photo module" data-stellar-background-ratio="0.2">';
   $output .= ' <div class="container">';
     $output .= ' <div class="row">';
       $output .= ' <div class="col-sm-8 lj-photo-texts">';
          $output .= '<h2>'. $heading . '</h2>';
          $output .= '<p>'. esc_html($description) . '</p>';
        if ($button_left_text != ''){  $output .= '<a href="'. esc_url($button_left_url) . '" class="lj-photo-button wow fadeInDown" data-wow-delay="0.5s">'. esc_html($button_left_text) . '</a>'; }
        $output .= '</div>';
     $output .= ' </div>';
    $output .= '</div>';
  $output .= '</div>';


return $output;
}
add_shortcode('vc_parallax', 'theme_vc_parallax');


/*-----------------------------------------------------------------------------------*/
/*	icon boxes
/*-----------------------------------------------------------------------------------*/

function theme_vc_icon_module( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"section_id" => '',
	"heading_color" => '',
	"bg_color" => '',
	"slogan" => '',
	"heading" => ''
	), $atts) );
	$id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$output = '';
	$output .= '<style>';
	$output .= '#'.$section_id.' .icons.module {  background-color: '. esc_attr($bg_color) . '; } ';
	$output .= '#'.$section_id.' h2 {  color: '. esc_attr($heading_color) . '; } ';
	$output .= '</style>';

	$output .= '<div '.$id.' class="icons module">';
		$output .= '<div class="container">';

			$output .= '<div class="row">';
			$output .= '<div class="col-sm-12 lj-icons-title">';
			if ($heading != ''){ $output .= '<h2>'. $heading . '</h2>'; }
			if ($slogan != '') { $output .= '<p>'. $slogan . '</p>';    }
			$output .= '</div>';
			$output .= '</div>';

			$output .= ' <div class="row">';
			$output .= ''. do_shortcode($content) . '';
			$output .= '</div>';
		$output .= '</div>';
	$output .= '</div>';


return $output;
}
add_shortcode('vc_icon_module', 'theme_vc_icon_module');

/*-----------------------------------------------------------------------------------*/
/*	icon module item
/*-----------------------------------------------------------------------------------*/

function theme_vc_icon_module_item( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"column_id" => '',
	"heading_color" => '',
	"bg_color" => '',
	"icon_color" => '',
	"description_color" => '',
	"icon_fontawesome" => '',
	"description" => '',
	"heading" => ''
	), $atts) );
	$output = '';
	$id = ($column_id != '') ? 'id="'. esc_attr($column_id) . '"' : '';
	if ($column_id != ''){
	$output .= '<style>';
	$output .= '#'.$column_id.' .lj-icon-box {  color: '. esc_attr($bg_color) . '; } ';
	$output .= '#'.$column_id.' h3 {  color: '. esc_attr($heading_color) . '; } ';
	$output .= '#'.$column_id.' p {  color: '. esc_attr($description_color) . '; } ';
	$output .= '#'.$column_id.' span {  color: '. esc_attr($icon_color) . '; } ';
	$output .= '</style>';
	 }
	if ($column_id != ''){
	$output .= '<div '.$id.' class="col-sm-6 col-md-3 m-b-20 lj-icon-box wow fadeInDown" data-wow-delay="0.5s">';
	} else {
	$output .= '<div class="col-sm-6 col-md-3 m-b-20 lj-icon-box wow fadeInDown" data-wow-delay="0.5s">';
	}
         $output .= ' <div>';
			if($icon_fontawesome == true){ $output .= '<span><i class="'.$icon_fontawesome.'"></i></span>'; }
            $output .= '<h3>'. $heading . '</h3>';
            $output .= '<p>'. $description . '</p>';
          $output .= '</div>';
       $output .= ' </div>';
	return $output;
}
add_shortcode('vc_icon_module_item', 'theme_vc_icon_module_item');


/*-----------------------------------------------------------------------------------*/
/*	parallax
/*-----------------------------------------------------------------------------------*/

function theme_vc_parallax_two( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"section_id" => '',
	"heading_color" => '',
	"text_color" => '',
	"heading" => '',
	"button_right_text" => '',
	"button_right_url" => '',
	"button_left_url" => '',
	"button_left_text" => ''
	), $atts) );
	$output = '';
	$id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	if ($id != ''){
	$output .= '<style>';
	$output .= '#'.$section_id.' h2 {  color: '. esc_attr($heading_color) . '; } ';
	$output .= '#'.$section_id.' p {  color: '. esc_attr($text_color) . '; } ';
	$output .= '</style>';
	}

	if ($id != ''){
	$output .= '<div '.$id.' class="photo-centered module">';
	} else { $output .= '<div class="photo-centered module">'; }
    $output .= '<div class="container">';
		$output .= '<div class="row">';
			$output .= ' <div class="col-sm-8 col-sm-offset-2 lj-photo-centered-texts">';
			$output .= '<h2>'. $heading . '</h2>';
			$output .= ''. $content .'';
			if ($button_left_text != ''){ $output .= '<a href="'. esc_url($button_left_url) . '" class="lj-photo-centered-button wow fadeInDown" data-wow-delay="0.5s"><i class="fa fa-apple"></i> '. esc_html($button_left_text) . '</a>';}
			if ($button_right_text != ''){ $output .= '<a href="'. esc_url($button_right_url) . '" class="lj-photo-centered-button wow fadeInDown" data-wow-delay="1s"><i class="fa fa-android"></i> '. esc_html($button_right_text) . '</a>'; }
			$output .= '</div>';
			$output .= '</div>';
		$output .= '</div>';
	$output .= '</div>';
	return $output;
}
add_shortcode('vc_parallax_two', 'theme_vc_parallax_two');


/*-----------------------------------------------------------------------------------*/
/*	subscribe
/*-----------------------------------------------------------------------------------*/

function theme_vc_subscribe( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"section_id" => '',
	"heading_color" => '',
	"text_color" => '',
	"heading" => '',
	"description" => ''
	), $atts) );
	$output = '';
	$id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	if ($id != ''){
	$output .= '<style>';
	$output .= ''.$section_id.' h2 {  color: '. esc_attr($heading_color) . '; } ';
	$output .= ''.$section_id.' p {  color: '. esc_attr($text_color) . '; } ';
	$output .= '</style>';
	}
	if ($id != ''){
	$output .= '<div '.$id.' class="subscribe module">';
	} else { $output .= '<div class="subscribe module">'; }
	$output .= ' <div class="container">';
      $output .= '<div class="row">';
        $output .= '<div class="col-md-12 col-lg-6 lj-subscribe-title">';
         $output .= ' <h3>'. $heading . '</h3>';
          $output .= '<p>'. $description . '</p>';
       $output .= ' </div>';
        $output .= '<div class="col-md-12 col-lg-6 lj-subscribe-form wow fadeInDown" data-wow-delay="0.5s">';
         $output .= ''. do_shortcode($content) . '';
        $output .= '</div>';
      $output .= '</div>';
	$output .= ' </div>';
	$output .= '</div>';

	return $output;
}
add_shortcode('vc_subscribe', 'theme_vc_subscribe');



/*-----------------------------------------------------------------------------------*/
/*	parallax
/*-----------------------------------------------------------------------------------*/

function theme_vc_promo( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"button_left_url" => '',
	"button_left_text" => '',
	"icon_fontawesome" => '',
	"first_text" => '',
	"second_text" => '',
	"third_text" => '',
	"section_id" => '',
	"heading_color" => '',
	"bg_color" => '',
	"heading" => '',
	"description" => ''
	), $atts) );
	$output = '';
	wp_enqueue_script('ninetheme_holywood-wordrotator-js');

	$id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	if ($id != ''){
	$output .= '<style>';
	$output .= ''.$section_id.' h2 {  color: '. esc_attr($heading_color) . '; } ';
	$output .= ''.$section_id.' {  background-color: '. esc_attr($bg_color) . '; } ';
	$output .= '</style>';
	}
	if ($id != ''){
	$output .= '<div '.$id.' class="promo module">';
	} else { $output .= '<div class="promo module">'; }

    $output .= '<div class="container">';
      $output .= '<div class="row">';
       $output .= '<div class="col-sm-12 lj-promo">';
          $output .= '<h2><span id="words"></span></h2>';
          if ($button_left_text != ''){
		  $output .= '<a class="wow fadeInDown" data-wow-delay="0.5s" href="'. esc_url($button_left_url) . '">';
		 if($icon_fontawesome == true){ $output .= '<i class="'.$icon_fontawesome.'"></i>'; }
		   $output .= ''. esc_html($button_left_text) . '</a>'; }
        $output .= '</div>';
      $output .= '</div>';
    $output .= '</div>';
  $output .= '</div>';

  wp_enqueue_script('ninetheme_holywood-wordrotator-js');
  wp_add_inline_script( 'ninetheme_holywood-wordrotator-js',
  'jQuery(document).ready(function($){
      $("#words").wordsrotator({
      autoLoop: true,
      randomize: false,
      stopOnHover: false,
      changeOnClick: false,
      animationIn: "fadeIn",
      animationOut: "fadeOut",
      speed: 25000,
      words: [\''.$first_text.'\',\''.$second_text.'\',\''.$third_text.'\']
    });
  });' );

return $output;
}
add_shortcode('vc_promo', 'theme_vc_promo');


/*-----------------------------------------------------------------------------------*/
/*	product photos
/*-----------------------------------------------------------------------------------*/

function theme_vc_photos( $atts, $content = null ) {
    extract( shortcode_atts(array(
	), $atts) );
$output = '';
	$output .= '<div class="photos-texts module"><div class="container">';
		$output .= ''. do_shortcode($content) . '';
	$output .= '</div></div>';
return $output;
}
add_shortcode('vc_photos', 'theme_vc_photos');


/*-----------------------------------------------------------------------------------*/
/*	product photos item
/*-----------------------------------------------------------------------------------*/

function theme_vc_photos_item( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"image_position" => 'left',
	"image" => '',
	"heading" => ''

	), $atts) );

    $imagealt = get_post_meta($image, '_wp_attachment_image_alt', true);
    $imagealt = $imagealt ? $imagealt : basename ( get_attached_file( $image ) );

	$image_url = wp_get_attachment_url( $image, 'full' );
	$image = function_exists('aq_resize') ? aq_resize( $image_url, 600, null, true, true, true ) : $image_url;

	$output = '';

	$output .= '<div class="row">';
	if ($image_position != 'left'){
		$output .= '<div class="col-sm-6 lj-photos-texts-image wow fadeInDown" data-wow-delay="0.5s">';
		if ($image != ''){ $output .= '<img src="'. esc_url($image) . '" alt="'.$imagealt.'">'; }
		$output .= '</div>';
	}
		$output .= '<div class="col-sm-6 lj-photos-texts">';
			$output .= '<h3>'. $heading  . '</h3>';
		$output .= ''. $content . '';
		$output .= '</div>';

	if ($image_position != 'right'){
		$output .= ' <div class="col-sm-6 lj-photos-texts-image wow fadeInDown" data-wow-delay="0.5s">';
		if ($image != ''){ $output .= '<img src="'. esc_url($image) . '" alt="'.$imagealt.'">'; }
		$output .= '</div>';
	}
	$output .= '</div>';
return $output;
}
add_shortcode('vc_photos_item', 'theme_vc_photos_item');

/*-----------------------------------------------------------------------------------*/
/*	price table
/*-----------------------------------------------------------------------------------*/

function theme_vc_price_table($atts){
	extract(shortcode_atts(array(
       	'orderby' => 'date',
       	'order' => 'DESC',
       	'post_number' => '3',
       	'price_category' => 'all',
		'section_id' => '',
		'heading' => '',
		'slogan' => ''
    ), $atts));
    $id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
    global $post;
	$blog_post_type = '';

	$args = array( 'post_type' => 'price',
	'posts_per_page' => $post_number,
	'order' => $order,
	'orderby' => $orderby,
	'post_status' => 'publish'
	);

    if($price_category != 'all'){
    	$str = $price_category;
    	$arr = explode(',', $str);
		$args['tax_query'][] = array( 'taxonomy' 	=> 'price_category', 'field' 	=> 'slug', 'terms' 	=> $arr );
	}

    query_posts( $args );
    $output = '';

	if( have_posts() ) :
	$count = 0;

	$output .='<div '.$id.' class="pricing-table module">';
	$output .=' <div class="container"><div class="row"><div class="col-sm-8 col-sm-offset-2 lj-pricing-table-title">';
		if ($heading != ''){ $output .= '<h2>'. esc_html($heading) . '</h2>'; }
		if ($slogan != '') { $output .= '<p>'. esc_html($slogan) . '</p>';    }
	$output .=' </div></div>';

	while ( have_posts() ) : the_post();
	$count++;

		$offsetcolumn = get_post_meta( get_the_ID(), 'holywood_offset', true );
		$anime 	 	  =	get_post_meta( get_the_ID(), 'holywood_table_anime', true );
		$best 		  = get_post_meta( get_the_ID(), 'holywood_best', true );
		$best_value   = get_post_meta( get_the_ID(), 'holywood_best_value', true );
		$table_price  =  get_post_meta( get_the_ID(), 'holywood_table_price', true );
		$table_time   =   get_post_meta( get_the_ID(), 'holywood_table_time', true );
		$table_name   =   get_post_meta( get_the_ID(), 'holywood_table_name', true );
		$table_slogan = get_post_meta( get_the_ID(), 'holywood_table_slogan', true );
		$table_link   =   get_post_meta( get_the_ID(), 'holywood_table_link', true );
	$table_link_text  =  get_post_meta( get_the_ID(), 'holywood_table_link_text', true );
		$contents     =     get_post_meta( get_the_ID(), 'holywood_features_list', true );
		$featured     = ($best == 'yes') ? 'lj-pricing-table-featured' : '';

       $output .=' <div class="col-md-4 lj-pricing-table-normal '.$featured.' '.$offsetcolumn.'  wow bounceIn" data-wow-delay="'.$anime.'">';
        if($best_value !='') { $output .=' <span>'.$best_value.'</span>'; }
          $output .='<div>';
            $output .='<h4>'.$table_name.'</h4>';
            $output .='<p>'.$table_slogan.'</p>';
            $output .='<span>'.$table_price.'<span>/ '.$table_time.'</span></span>';
  			if($contents) {
				$output .= '<ul>';
				foreach ($contents as $content) { $output .= '<li>'.$content.'</li>'; }
				$output .= '</ul>';
		    }
            $output .='<a href="'.$table_link.'">'.$table_link_text.'</a>';
          $output .='</div>';
        $output .='</div>';
	endwhile;

	$output .='</div>';
	$output .='</div>';

	endif; return $output;
}
add_shortcode('vc_price_table', 'theme_vc_price_table');

/*-----------------------------------------------------------------------------------*/
/*	subscribe
/*-----------------------------------------------------------------------------------*/

function theme_vc_join( $atts, $content = null ) {
    extract( shortcode_atts(array(
	"section_id" => '',
	"bg_color" => '',
	"heading_color" => '',
	"text_color" => '',
	"heading" => '',
	"slogan" => ''
	), $atts) );
	$output = '';
	 $id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	if ($id != ''){
	$output .= '<style>';
	$output .= '#'.$section_id.' h2 {  color: '. esc_attr($heading_color) . '; } ';
	$output .= '#'.$section_id.' p {  color: '. esc_attr($text_color) . '; } ';
	$output .= '#'.$section_id.'  {  background-color: '. esc_attr($bg_color) . '; } ';
	$output .= '</style>';
	}
	if ($id != ''){
	$output .= '<div '.$id.' class="join-now module">';
	} else { $output .= '<div class="join-now module">'; }

   $output .= ' <div class="container">';
      $output .= '<div class="row">';
       $output .= ' <div class="col-sm-8 col-sm-offset-2 lj-join-now-title">';
         if ($heading != ''){ $output .= '<h2>'. $heading . '</h2>'; }
		if ($slogan != '') { $output .= '<p>'. $slogan . '</p>';    }
        $output .= '</div>';
     $output .= ' </div>';

     $output .= ' <div class="row">';
        $output .= '<div class="col-sm-12 lj-join-now-form wow fadeInUp" data-wow-delay="0.5s">';
		$output .= ''. do_shortcode($content) . '';
       $output .= '</div></div></div></div>';

	return $output;
}
add_shortcode('vc_join', 'theme_vc_join');

/*-----------------------------------------------------------------------------------*/
/*	clients
/*-----------------------------------------------------------------------------------*/

function theme_vc_clients( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'section_id' => '',
		'heading' => '',
		'description' => '',
		'sectionid' => ''
    ), $atts ) );
 $id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$output = '';
	$output .= '<div '.$id.' class="clients module">';
    $output .= '<div class="container">';
     $output .= ' <div class="row">';
        $output .= '<div class="col-sm-8 col-sm-offset-2 lj-clients-title">';
        if ($heading != ''){		$output .= '	<h2>'. $heading . '</h2>'; }
		if ($description != ''){	$output .= '<p>'. $description . '</p>'; }
       $output .= ' </div>';
	$output .= ' </div>';

	$output .= '<div class="row">';
	$output .= '<div class="col-sm-12 lj-clients wow fadeIn" data-wow-delay="0.5s">';
	$output .= '<div class="lj-clients-carousel">';
		$output .= ''. do_shortcode($content) . '';
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	return $output;

}

add_shortcode('vc_clients', 'theme_vc_clients');

/*-----------------------------------------------------------------------------------*/
/*	clients item
/*-----------------------------------------------------------------------------------*/

function theme_vc_clients_item( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'images' => '',
		'thumb_size' => 'ninetheme_holywood_member_thumb'
    ), $atts ) );

	$array_images = explode(",", $images);
	$output = '';
 	$output .= ' <div class="row">';
	$i = 0;
	foreach($array_images as $single_image) {
		$img_size = '';
		$img_size = wpb_getImageBySize(array('attach_id' => (int)$single_image, 'thumb_size' => $thumb_size));
		$output .= '<div class="col-xs-6 col-sm-3 lj-clients-item">';
			$output .= $img_size['thumbnail'];
		$output .= ' </div>';
		$i++; }
	$output .= ' </div>';
	return $output;
}

add_shortcode('vc_clients_item', 'theme_vc_clients_item');

/*-----------------------------------------------------------------------------------*/
/*	clients
/*-----------------------------------------------------------------------------------*/

function theme_vc_team( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'heading' => '',
		'description' => '',
		'section_id' => ''
    ), $atts ) );
	$id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$output = '';
	$output .= '<div '.$id.' class="team module">';
    $output .= '<div class="container">';
     $output .= ' <div class="row">';
        $output .= '<div class="col-sm-8 col-sm-offset-2 lj-clients-title">';
        if ($heading != ''){ $output .= '<h2>'. $heading . '</h2>'; }
		if ($description != ''){ $output .= '<p>'. $description . '</p>'; }
       $output .= ' </div>';
	$output .= ' </div>';

	$output .= '<div class="row">';
	$output .= '<div class="col-sm-12 lj-team wow fadeIn" data-wow-delay="0.5s">';
	$output .= '<div class="row">';
		$output .= do_shortcode($content);
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	return $output;

}

add_shortcode('vc_team', 'theme_vc_team');

/*-----------------------------------------------------------------------------------*/
/*	team item
/*-----------------------------------------------------------------------------------*/

function theme_vc_team_item( $atts, $content = null ) {
	$atts = shortcode_atts( array(
		'offset_class' => '',
		'team_img' => '',
		'name' => '',
		'values' =>'',
		'url' => '',
		'icon' => ''
    ), $atts );
	$team_img_url = wp_get_attachment_url( $atts['team_img'],'full' );
    $image = function_exists('aq_resize') ? aq_resize( $team_img_url, 360, null, true, true, true ) : $team_img_url;
    $imagealt = get_post_meta($atts['team_img'], '_wp_attachment_image_alt', true);
    $imagealt   = $imagealt ? $imagealt : basename ( get_attached_file( $atts['team_img'] ) );
	$values = (array) vc_param_group_parse_atts($atts['values']);
	$output = '';
	$output .= '<div class="col-xs-6 col-sm-3 '. esc_attr($atts['offset_class']) . '">';
		$output .= '<div class="lj-team-person">';
			if($image != ''){ $output .= '<img src="'.$image.'" alt="' . $imagealt . '" class="img-responsive"/>';}
			$output .= '<div>';
				if ($atts['name'] != ''){ $output .= '<p>'. esc_html($atts['name']) . '</p>'; }
				$output .= '<p>';
					foreach ( $values as $v ) {
                        $icon = isset($v['icon']) != '' ? $v['icon'] : '';
                        $url = isset($v['url']) != '' ? $v['url'] : '#';
                        if($icon){
                            $output .= '<a class="fa fa-'.$icon.'" href="'.$url.'"></a>';
                        }
					}
				$output .= '</p>';
			$output .= '</div>';
		$output .= '</div>';
	$output .= '</div>';

	return $output;
}

add_shortcode('vc_team_item', 'theme_vc_team_item');


/*-----------------------------------------------------------------------------------*/
/*	project
/*-----------------------------------------------------------------------------------*/

function theme_vc_project( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'heading' => '',
		'description' => '',
		'section_id' => ''
    ), $atts ) );
	$id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$output = '';
	$output .= '<div '.$id.' class="projects module">';
    $output .= '<div class="container">';
     $output .= ' <div class="row">';
        $output .= '<div class="col-sm-8 col-sm-offset-2 lj-clients-title">';
        if ($heading != ''){ $output .= '<h2>'. esc_html($heading) . '</h2>'; }
		if ($description != ''){ $output .= '<p>'. esc_html($description) . '</p>'; }
       $output .= ' </div>';
	$output .= ' </div>';

	$output .= '<div class="row">';
	$output .= '<div class="col-sm-12 lj-projects wow fadeIn" data-wow-delay="0.5s">';
	$output .= '<div class="row">';
		$output .= do_shortcode($content);
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	return $output;

}

add_shortcode('vc_project', 'theme_vc_project');

/*-----------------------------------------------------------------------------------*/
/*	project item
/*-----------------------------------------------------------------------------------*/

function theme_vc_project_item( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'project_img' => '',
		'heading' => '',
		'description' => ''
    ), $atts ) );

    $imagealt = get_post_meta($project_img, '_wp_attachment_image_alt', true);
    $imagealt = $imagealt ? $imagealt : basename ( get_attached_file( $project_img ) );

	$project_img = wp_get_attachment_url( $project_img,'full' );
    $image = function_exists('aq_resize') ? aq_resize( $project_img, 800, null, true, true, true ) : $project_img;

	$output = '';
	$output .= '<div class="col-sm-12 col-md-4">';
	$output .= '<div class="lj-projects-item">';
	 if($image != ''){	$output .= '<img src="'.$image.'" alt="' . $imagealt . '" class="img-responsive"/>';}
	  $output .= '<div>';
		$output .= '<h3>'. esc_html($heading) . '</h3>';
		$output .= '<p>'. esc_html($description) . '</p>';
		 if($image != ''){ $output .= '<a href="'.$image.'">preview</a>'; }
	  $output .= '</div>';
	$output .= '</div>';
	$output .= '</div>';
	return $output;
}

add_shortcode('vc_project_item', 'theme_vc_project_item');


/*-----------------------------------------------------------------------------------*/
/*	project
/*-----------------------------------------------------------------------------------*/

function theme_vc_testimonials( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'heading_type' => 'icon',
		'heading' => '',
		'description' => '',
		'section_id' => ''
    ), $atts ) );
	$id = ($section_id != '') ? 'id="'. esc_attr($section_id) . '"' : '';
	$output = '';
	$output .= '<div '.$id.' class="testimonials module">';
    $output .= '<div class="container">';
	$output .= ' <div class="row">';
	if ($heading_type == 'text'){
        $output .= '<div class="col-sm-8 col-sm-offset-2 lj-clients-title">';
        if ($heading != ''){		$output .= '	<h2>'. esc_html($heading) . '</h2>'; }
		if ($description != ''){	$output .= '<p>'. esc_html($description) . '</p>'; }
	$output .= ' </div>';
	} else {
	$output .= '<div class="col-sm-12 lj-testimonials-icon">';
		$output .= '<i class="fa fa-quote-right"></i>';
	$output .= ' </div>';
	}
	$output .= ' </div>';

	$output .= '<div class="row">';
	$output .= '<div class="col-sm-12 lj-testimonials wow fadeIn" data-wow-delay="0.5s">';
	$output .= '<div class="lj-carousel">';

		$output .= ''. do_shortcode($content) . '';

	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	$output .= ' </div>';
	return $output;

}

add_shortcode('vc_testimonials', 'theme_vc_testimonials');

/*-----------------------------------------------------------------------------------*/
/*	project item
/*-----------------------------------------------------------------------------------*/

function theme_vc_testimonials_item( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'testi_img' => '',
		'testi_imga' => '',
		'name' => '',
		'namea' => '',
		'position' => '',
		'positiona' => '',
		'descriptiona' => '',
		'description' => ''
    ), $atts ) );

    $imagealt = get_post_meta($testi_img, '_wp_attachment_image_alt', true);
    $imagealt1 = $imagealt ? $imagealt : basename ( get_attached_file( $testi_img ) );
    $imagealt2 = get_post_meta($testi_imga, '_wp_attachment_image_alt', true);
    $imagealt2 = $imagealt2 ? $imagealt2 : basename ( get_attached_file( $testi_imga ) );

	$team_img_url = wp_get_attachment_url( $testi_img,'full' );
    $image = function_exists('aq_resize') ? aq_resize( $team_img_url, 75, null, true, true, true ) : $team_img_url;


	$team_img_urla = wp_get_attachment_url( $testi_imga,'full' );
    $imagea = function_exists('aq_resize') ? aq_resize( $team_img_urla, 75, null, true, true, true ) : $team_img_urla;

	$output = '';
	$output .= '<div class="row">';

	$output .= '<div class="col-sm-6">';
	if($description != ''){ $output .= '<blockquote>'. esc_html($description) . '</blockquote>'; }
	if($image != ''){ $output .= ' <img src="'.$image.'" alt="'.$imagealt1.'">'; }
	if($name != ''){$output .= '<p><strong>'. esc_html($name) . '</strong>'. esc_html($position) . '</p>'; }
	$output .= '</div>';

	$output .= '<div class="col-sm-6">';
	if($descriptiona != ''){ $output .= '<blockquote>'. esc_html($descriptiona) . '</blockquote>'; }
	if($imagea != ''){ $output .= ' <img src="'.$imagea.'" alt="'.$imagealt2.'">'; }
	if($namea != ''){$output .= '<p><strong>'. esc_html($namea) . '</strong>'. esc_html($positiona) . '</p>'; }
	$output .= '</div>';

	$output .= '</div>';

	return $output;
}

add_shortcode('vc_testimonials_item', 'theme_vc_testimonials_item');

?>
